# Aufgaben von Linus Schumann
**Teilnahme-ID: 68772**

**Team-ID: 00083**

**Letze Änderung: 14.11.2023**

## Bearbeitete Aufgaben:
* Aufgabe 3: Zauberschule
* Aufgabe 4: Nandu
* Aufgabe 5: Stadtführung

## Inhalt einer Aufgabe:
* source: Alle C++/Python Quelltextdateien
* beispieldaten: Alle verwendeten Beispieldaten aus der Dokumentation
* beispielausgaben: Alle Ausgaben der Beispieldaten
* executable:
  * Nur bei C++-Implementierung: Ausführbare .exe Datei
    * Auf Windows mit g++ kompiliert
  * Batch-Datei zum Starten des Programms
## Besonderer Ordner bei Aufgabe 4:
* web-app: Ordner mit allen JavaScript, HTML und CSS Dateien für die Zusatzaufgabe