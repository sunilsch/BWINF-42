Jede Datei beschreibt eine Konstruktion und enthält
-in der ersten Zeile die Breite n und die Höhe m der Konstruktion
-und in den folgenden m Zeilen eine Darstellung der Konstruktion.
In der ersten Zeile der Konstruktion sind immer die Taschenlampen mit ‚Q*‘ angegeben. In der letzten Zeile der Konstruktion sind immer die LEDs mit ‚L*‘ gegeben. 
Ein einzelner Baustein hat immer eine Breite von zwei. Ein weißer Baustein ist also gegeben mit ‚W W‘, einer roter Baustein mit ‚R R‘ und ein blauer Baustein mit ‚B B‘. Ein nicht belegtes Feld ist mit einem ‚X‘ markiert. Bei einem roten Baustein markiert das große ‚R‘ jeweils die Position des Lichtsensors und ein kleines ‚r‘, dass an dieser Stelle kein Lichtsensor ist.

Die Datei nandu1.txt entspricht der rechten Konstruktion auf dem Aufgabenblatt.